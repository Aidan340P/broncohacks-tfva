export type SourceType = "text" | "audio" | "live" | "library";

export type UserNote = {
  id: string;
  title: string;
  content: string;
  createdAt: string;
  updatedAt: string;
};

export type Lecture = {
  id: string;
  title: string;
  content: string;
  sourceType: SourceType;
  createdAt: string;
  updatedAt: string;
};

export type GenerateResponse = {
  notes: string;
  mode: "openai" | "fallback";
  styleNoteCount: number;
  warning?: string;
};

export type TranscribeResponse = {
  text: string;
  mode: "openai" | "fallback";
  filename: string;
  warning?: string;
};
