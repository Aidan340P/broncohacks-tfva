export function getErrorMessage(error: unknown): string {
  if (error instanceof Error) {
    return error.message;
  }

  return "Unknown error";
}

export function makeTitle(input: string, fallback: string): string {
  const trimmed = input.trim();
  if (!trimmed) {
    return fallback;
  }

  const [firstLine = ""] = trimmed.split(/\r?\n/);
  const cleaned = firstLine.replace(/^#+\s*/, "").trim();

  if (cleaned.length >= 4 && cleaned.length <= 80) {
    return cleaned;
  }

  const words = trimmed
    .replace(/\s+/g, " ")
    .split(" ")
    .filter(Boolean)
    .slice(0, 8)
    .join(" ");

  return words ? `${words}${trimmed.length > words.length ? "..." : ""}` : fallback;
}

export function formatDate(isoString: string): string {
  try {
    return new Date(isoString).toLocaleString();
  } catch {
    return isoString;
  }
}

export function excerpt(text: string, maxLength = 180): string {
  const normalized = text.replace(/\s+/g, " ").trim();
  if (normalized.length <= maxLength) {
    return normalized;
  }

  return `${normalized.slice(0, maxLength).trimEnd()}...`;
}
