import type { UserNote } from "@/types";
import { makeTitle } from "@/lib/utils";

function detectBulletPrefix(styleNotes: UserNote[]): string {
  const joined = styleNotes.map((note) => note.content).join("\n");
  if (joined.includes("->")) return "->";
  if (joined.includes("* ")) return "*";
  if (joined.includes("•")) return "•";
  return "-";
}

function useLowercaseHeadings(styleNotes: UserNote[]): boolean {
  const headings = styleNotes
    .flatMap((note) => note.content.split(/\r?\n/))
    .map((line) => line.trim())
    .filter((line) => line.length > 0 && line.length < 32);

  if (headings.length === 0) return false;

  const lowercaseCount = headings.filter((line) => line === line.toLowerCase()).length;
  return lowercaseCount / headings.length > 0.5;
}

function shorten(line: string, maxLength = 120): string {
  const cleaned = line.replace(/\s+/g, " ").trim();
  if (cleaned.length <= maxLength) return cleaned;
  return `${cleaned.slice(0, maxLength).trimEnd()}...`;
}

function applyShorthand(line: string, styleNotes: UserNote[]): string {
  const styleText = styleNotes.map((note) => note.content).join("\n");
  let nextLine = line;

  if (styleText.includes("b/c")) nextLine = nextLine.replace(/\bbecause\b/gi, "b/c");
  if (styleText.includes("w/")) nextLine = nextLine.replace(/\bwith\b/gi, "w/");
  if (styleText.includes("w/o")) nextLine = nextLine.replace(/\bwithout\b/gi, "w/o");
  if (styleText.includes(" vs ")) nextLine = nextLine.replace(/\bversus\b/gi, "vs");

  return nextLine;
}

function splitIntoIdeaUnits(input: string): string[] {
  const paragraphs = input
    .split(/\r?\n+/)
    .map((paragraph) => paragraph.trim())
    .filter(Boolean);

  const collected: string[] = [];

  for (const paragraph of paragraphs) {
    if (/^[-*•]\s/.test(paragraph)) {
      collected.push(paragraph.replace(/^[-*•]\s*/, ""));
      continue;
    }

    const sentences = paragraph
      .split(/(?<=[.!?])\s+/)
      .map((sentence) => sentence.trim())
      .filter(Boolean);

    if (sentences.length > 0) {
      collected.push(...sentences);
    }
  }

  return collected.filter((line) => line.length > 12);
}

export function buildFallbackNotes(input: string, styleNotes: UserNote[], title?: string): string {
  const bullet = detectBulletPrefix(styleNotes);
  const lowercaseHeadings = useLowercaseHeadings(styleNotes);
  const ideaUnits = splitIntoIdeaUnits(input);
  const displayTitle = title?.trim() || makeTitle(input, "Generated Notes");
  const headingOverview = lowercaseHeadings ? "overview" : "Overview";
  const headingDetails = lowercaseHeadings ? "key details" : "Key Details";
  const headingTakeaway = lowercaseHeadings ? "takeaway" : "Takeaway";

  const points = ideaUnits.slice(0, 6).map((line) => shorten(applyShorthand(line, styleNotes)));
  const takeaway = shorten(applyShorthand(ideaUnits[ideaUnits.length - 1] ?? input, styleNotes));

  const lines = [
    displayTitle,
    "",
    `${headingOverview}:`,
    `${bullet} ${shorten(applyShorthand(ideaUnits[0] ?? input, styleNotes))}`,
    "",
    `${headingDetails}:`,
    ...points.slice(1).map((point) => `${bullet} ${point}`),
    "",
    `${headingTakeaway}:`,
    `${bullet} ${takeaway}`,
  ];

  if (styleNotes.length < 3) {
    lines.push("", "[offline demo mode: add 3+ style notes + an OpenAI API key for stronger results]");
  }

  return lines.join("\n").replace(/\n{3,}/g, "\n\n");
}
