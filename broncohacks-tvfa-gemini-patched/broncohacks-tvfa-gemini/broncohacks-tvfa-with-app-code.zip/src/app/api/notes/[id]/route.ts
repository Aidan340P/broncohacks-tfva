import { NextResponse } from "next/server";
import { getNoteById, removeNote, saveNote } from "@/lib/storage";
import { makeTitle } from "@/lib/utils";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type UpdateNoteBody = {
  title?: string;
  content?: string;
};

type RouteContext = {
  params: Promise<{ id: string }>;
};

export async function GET(_request: Request, { params }: RouteContext) {
  const { id } = await params;
  const note = await getNoteById(id);

  if (!note) {
    return NextResponse.json({ error: "Note not found." }, { status: 404 });
  }

  return NextResponse.json({ note });
}

export async function PUT(request: Request, { params }: RouteContext) {
  const { id } = await params;
  const existingNote = await getNoteById(id);

  if (!existingNote) {
    return NextResponse.json({ error: "Note not found." }, { status: 404 });
  }

  const body = (await request.json()) as UpdateNoteBody;
  const content = body.content?.trim();

  if (!content) {
    return NextResponse.json({ error: "Note content is required." }, { status: 400 });
  }

  const updatedNote = {
    ...existingNote,
    title: body.title?.trim() || makeTitle(content, existingNote.title),
    content,
    updatedAt: new Date().toISOString(),
  };

  await saveNote(updatedNote);
  return NextResponse.json({ note: updatedNote });
}

export async function DELETE(_request: Request, { params }: RouteContext) {
  const { id } = await params;
  const deleted = await removeNote(id);

  if (!deleted) {
    return NextResponse.json({ error: "Note not found." }, { status: 404 });
  }

  return NextResponse.json({ success: true });
}
