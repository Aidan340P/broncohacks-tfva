import OpenAI from "openai";
import { NextResponse } from "next/server";
import { getErrorMessage } from "@/lib/utils";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const formData = await request.formData();
  const file = formData.get("file");

  if (!(file instanceof File)) {
    return NextResponse.json({ error: "Audio file is required." }, { status: 400 });
  }

  if (!process.env.OPENAI_API_KEY) {
    return NextResponse.json({
      text: `Transcription fallback for ${file.name}: add OPENAI_API_KEY to get real transcription, or paste lecture text manually for now.`,
      mode: "fallback",
      filename: file.name,
      warning: "OPENAI_API_KEY is not set, so the audio was not actually transcribed.",
    });
  }

  try {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const transcription = await client.audio.transcriptions.create({
      file,
      model: process.env.OPENAI_TRANSCRIPTION_MODEL ?? "whisper-1",
    });

    return NextResponse.json({
      text: transcription.text,
      mode: "openai",
      filename: file.name,
    });
  } catch (error) {
    return NextResponse.json({
      text: `Transcription failed for ${file.name}. Add a valid API key or paste lecture text manually.`,
      mode: "fallback",
      filename: file.name,
      warning: `OpenAI transcription failed (${getErrorMessage(error)}).`,
    });
  }
}
