import OpenAI from "openai";
import { NextResponse } from "next/server";
import { buildFallbackNotes } from "@/lib/fallback";
import { listNotes } from "@/lib/storage";
import { getErrorMessage } from "@/lib/utils";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type GenerateBody = {
  input?: string;
  lectureTitle?: string;
};

function buildPrompt(input: string, lectureTitle: string | undefined, styleExamples: string[]) {
  return [
    `Lecture title: ${lectureTitle?.trim() || "Untitled lecture"}`,
    "",
    "User style examples:",
    styleExamples.length > 0 ? styleExamples.join("\n\n---\n\n") : "No style examples provided yet.",
    "",
    "Lecture content:",
    input,
  ].join("\n");
}

export async function POST(request: Request) {
  const body = (await request.json()) as GenerateBody;
  const input = body.input?.trim();

  if (!input) {
    return NextResponse.json({ error: "Lecture input is required." }, { status: 400 });
  }

  const notes = await listNotes();
  const fallbackNotes = buildFallbackNotes(input, notes, body.lectureTitle);

  if (!process.env.OPENAI_API_KEY) {
    return NextResponse.json({
      notes: fallbackNotes,
      mode: "fallback",
      styleNoteCount: notes.length,
      warning: "OPENAI_API_KEY is not set, so the app returned offline demo notes instead.",
    });
  }

  try {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL ?? "gpt-4o-mini",
      instructions:
        "You are NoteAI. Rewrite the lecture into concise study notes that imitate the user's style examples. Keep the output clean, readable, and directly useful for studying. Do not mention that you are an AI. Do not add commentary outside the notes.",
      input: buildPrompt(
        input,
        body.lectureTitle,
        notes.map((note) => `${note.title}\n${note.content}`),
      ),
    });

    const output = response.output_text?.trim();

    if (!output) {
      throw new Error("The model returned an empty response.");
    }

    return NextResponse.json({
      notes: output,
      mode: "openai",
      styleNoteCount: notes.length,
    });
  } catch (error) {
    return NextResponse.json({
      notes: fallbackNotes,
      mode: "fallback",
      styleNoteCount: notes.length,
      warning: `OpenAI request failed (${getErrorMessage(error)}). Returned offline demo notes instead.`,
    });
  }
}
