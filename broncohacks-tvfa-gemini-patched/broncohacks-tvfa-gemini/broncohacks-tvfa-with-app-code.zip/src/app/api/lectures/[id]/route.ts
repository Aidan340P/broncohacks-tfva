import { NextResponse } from "next/server";
import { getLectureById, removeLecture, saveLecture } from "@/lib/storage";
import { makeTitle } from "@/lib/utils";
import type { Lecture } from "@/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type UpdateLectureBody = {
  title?: string;
  content?: string;
  sourceType?: Lecture["sourceType"];
};

type RouteContext = {
  params: Promise<{ id: string }>;
};

export async function GET(_request: Request, { params }: RouteContext) {
  const { id } = await params;
  const lecture = await getLectureById(id);

  if (!lecture) {
    return NextResponse.json({ error: "Lecture not found." }, { status: 404 });
  }

  return NextResponse.json({ lecture });
}

export async function PUT(request: Request, { params }: RouteContext) {
  const { id } = await params;
  const existingLecture = await getLectureById(id);

  if (!existingLecture) {
    return NextResponse.json({ error: "Lecture not found." }, { status: 404 });
  }

  const body = (await request.json()) as UpdateLectureBody;
  const content = body.content?.trim();

  if (!content) {
    return NextResponse.json({ error: "Lecture content is required." }, { status: 400 });
  }

  const updatedLecture: Lecture = {
    ...existingLecture,
    title: body.title?.trim() || makeTitle(content, existingLecture.title),
    content,
    sourceType: body.sourceType ?? existingLecture.sourceType,
    updatedAt: new Date().toISOString(),
  };

  await saveLecture(updatedLecture);
  return NextResponse.json({ lecture: updatedLecture });
}

export async function DELETE(_request: Request, { params }: RouteContext) {
  const { id } = await params;
  const deleted = await removeLecture(id);

  if (!deleted) {
    return NextResponse.json({ error: "Lecture not found." }, { status: 404 });
  }

  return NextResponse.json({ success: true });
}
