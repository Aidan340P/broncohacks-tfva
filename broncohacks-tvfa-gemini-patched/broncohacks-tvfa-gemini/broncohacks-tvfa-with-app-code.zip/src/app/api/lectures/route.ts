import { randomUUID } from "node:crypto";
import { NextResponse } from "next/server";
import { listLectures, saveLecture } from "@/lib/storage";
import { makeTitle } from "@/lib/utils";
import type { Lecture } from "@/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type CreateLectureBody = {
  title?: string;
  content?: string;
  sourceType?: Lecture["sourceType"];
};

export async function GET() {
  const lectures = await listLectures();
  return NextResponse.json({ lectures });
}

export async function POST(request: Request) {
  const body = (await request.json()) as CreateLectureBody;
  const content = body.content?.trim();

  if (!content) {
    return NextResponse.json({ error: "Lecture content is required." }, { status: 400 });
  }

  const now = new Date().toISOString();
  const lecture: Lecture = {
    id: randomUUID(),
    title: body.title?.trim() || makeTitle(content, "Untitled Lecture"),
    content,
    sourceType: body.sourceType ?? "library",
    createdAt: now,
    updatedAt: now,
  };

  await saveLecture(lecture);
  return NextResponse.json({ lecture }, { status: 201 });
}
