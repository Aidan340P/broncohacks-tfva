import { getErrorMessage } from "@/lib/utils";

const GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta";

type GeminiTextResponse = {
  candidates?: Array<{
    content?: {
      parts?: Array<{
        text?: string;
      }>;
    };
  }>;
  error?: {
    message?: string;
  };
};

export function getGeminiApiKey() {
  return process.env.GEMINI_API_KEY?.trim() || process.env.GOOGLE_API_KEY?.trim() || null;
}

export function hasGeminiApiKey() {
  return Boolean(getGeminiApiKey());
}

function getGeminiModel() {
  return process.env.GEMINI_MODEL?.trim() || "gemini-2.5-flash";
}

function getGeminiTranscriptionModel() {
  return process.env.GEMINI_TRANSCRIPTION_MODEL?.trim() || getGeminiModel();
}

function extractGeminiText(payload: GeminiTextResponse) {
  const text = payload.candidates
    ?.flatMap((candidate) => candidate.content?.parts ?? [])
    .map((part) => part.text ?? "")
    .join("")
    .trim();

  if (!text) {
    throw new Error(payload.error?.message || "Gemini returned an empty response.");
  }

  return text;
}

async function callGemini(parts: Array<Record<string, unknown>>, model: string) {
  const apiKey = getGeminiApiKey();

  if (!apiKey) {
    throw new Error("Missing GEMINI_API_KEY or GOOGLE_API_KEY.");
  }

  const response = await fetch(`${GEMINI_API_URL}/models/${model}:generateContent`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-goog-api-key": apiKey,
    },
    body: JSON.stringify({
      contents: [
        {
          role: "user",
          parts,
        },
      ],
    }),
  });

  const payload = (await response.json()) as GeminiTextResponse;

  if (!response.ok) {
    throw new Error(payload.error?.message || `Gemini request failed with status ${response.status}.`);
  }

  return extractGeminiText(payload);
}

export async function generateNotesWithGemini(prompt: string) {
  return callGemini([{ text: prompt }], getGeminiModel());
}

export async function transcribeAudioWithGemini(file: File) {
  const bytes = Buffer.from(await file.arrayBuffer()).toString("base64");
  const mimeType = file.type || "audio/webm";
  const prompt = [
    "Generate a clean transcript of the speech in this audio file.",
    "Only return the transcript text.",
    "Do not add headings, notes, or commentary.",
  ].join(" ");

  return callGemini(
    [
      { text: prompt },
      {
        inline_data: {
          mime_type: mimeType,
          data: bytes,
        },
      },
    ],
    getGeminiTranscriptionModel(),
  );
}

export function buildGeminiWarning(error: unknown) {
  return `Gemini request failed (${getErrorMessage(error)}). Returned demo output instead.`;
}
