const GEMINI_API_BASE = "https://generativelanguage.googleapis.com/v1beta/models";

type GeminiPart =
  | { text: string }
  | { inline_data: { mime_type: string; data: string } };

type GeminiGenerateRequest = {
  model?: string;
  contents: Array<{
    parts: GeminiPart[];
  }>;
};

type GeminiResponse = {
  candidates?: Array<{
    content?: {
      parts?: Array<{
        text?: string;
      }>;
    };
    finishReason?: string;
  }>;
  promptFeedback?: {
    blockReason?: string;
  };
  error?: {
    message?: string;
  };
};

export function getGeminiApiKey() {
  return process.env.GEMINI_API_KEY?.trim() || null;
}

function getGeminiModel(modelOverride?: string) {
  return modelOverride?.trim() || process.env.GEMINI_MODEL?.trim() || "gemini-2.5-flash";
}

function extractText(payload: GeminiResponse) {
  const text = payload.candidates
    ?.flatMap((candidate) => candidate.content?.parts ?? [])
    .map((part) => part.text?.trim() || "")
    .filter(Boolean)
    .join("\n")
    .trim();

  if (text) {
    return text;
  }

  if (payload.promptFeedback?.blockReason) {
    throw new Error(`Gemini blocked the request: ${payload.promptFeedback.blockReason}`);
  }

  if (payload.error?.message) {
    throw new Error(payload.error.message);
  }

  throw new Error("Gemini returned an empty response.");
}

export async function generateGeminiText(request: GeminiGenerateRequest) {
  const apiKey = getGeminiApiKey();

  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is not set.");
  }

  const model = getGeminiModel(request.model);
  const response = await fetch(`${GEMINI_API_BASE}/${model}:generateContent`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-goog-api-key": apiKey,
    },
    body: JSON.stringify({ contents: request.contents }),
  });

  const payload = (await response.json()) as GeminiResponse;

  if (!response.ok) {
    throw new Error(payload.error?.message || `Gemini request failed with ${response.status}.`);
  }

  return extractText(payload);
}

export function fileToInlinePart(file: File): Promise<GeminiPart> {
  return file.arrayBuffer().then((buffer) => ({
    inline_data: {
      mime_type: file.type || "application/octet-stream",
      data: Buffer.from(buffer).toString("base64"),
    },
  }));
}
