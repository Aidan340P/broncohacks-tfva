export type SourceType = "text" | "audio" | "live";

export interface Note {
  id: string;
  title: string;
  content: string;
  createdAt: string;
  updatedAt: string;
}

export type UserNote = Note;

export interface Lecture {
  id: string;
  title: string;
  course?: string;
  instructor?: string;
  sourceType: SourceType;
  content: string;
  createdAt: string;
}

export interface NoteInput {
  title: string;
  content: string;
}

export interface LectureInput {
  title: string;
  course?: string;
  instructor?: string;
  content: string;
  sourceType?: SourceType;
}

export interface GenerateRequestBody {
  sourceText?: string;
  input?: string;
  lectureTitle?: string;
  selectedNoteIds?: string[];
}

export interface GenerateResponseBody {
  notes: string;
  styleSummary: string;
  mode: "gemini" | "fallback" | "demo";
  styleNoteCount?: number;
  warning?: string;
}

export type GenerateResponse = GenerateResponseBody;

export interface TranscribeResponseBody {
  transcript?: string;
  text?: string;
  filename?: string;
  mode: "gemini" | "fallback" | "demo";
  warning?: string;
}

export type TranscribeResponse = TranscribeResponseBody;
