import { NextResponse } from "next/server";
import { fileToInlinePart, generateGeminiText, getGeminiApiKey } from "@/lib/gemini";
import { getErrorMessage } from "@/lib/utils";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const formData = await request.formData();
  const file = formData.get("file");

  if (!(file instanceof File)) {
    return NextResponse.json({ error: "Audio file is required." }, { status: 400 });
  }

  if (!getGeminiApiKey()) {
    return NextResponse.json({
      text: `Transcription fallback for ${file.name}: add GEMINI_API_KEY to get real transcription, or paste lecture text manually for now.`,
      transcript: `Transcription fallback for ${file.name}: add GEMINI_API_KEY to get real transcription, or paste lecture text manually for now.`,
      mode: "fallback",
      filename: file.name,
      warning: "GEMINI_API_KEY is not set, so the audio was not actually transcribed.",
    });
  }

  try {
    const inlineAudio = await fileToInlinePart(file);
    const transcript = await generateGeminiText({
      model: process.env.GEMINI_TRANSCRIPTION_MODEL?.trim() || process.env.GEMINI_MODEL?.trim() || "gemini-2.5-flash",
      contents: [
        {
          parts: [
            { text: "Generate a clean transcript of the speech in this audio file. Output only the transcript text with no introduction or commentary." },
            inlineAudio,
          ],
        },
      ],
    });

    return NextResponse.json({
      text: transcript,
      transcript,
      mode: "gemini",
      filename: file.name,
    });
  } catch (error) {
    return NextResponse.json({
      text: `Transcription failed for ${file.name}. Add a valid Gemini AI Studio API key or paste lecture text manually.`,
      transcript: `Transcription failed for ${file.name}. Add a valid Gemini AI Studio API key or paste lecture text manually.`,
      mode: "fallback",
      filename: file.name,
      warning: `Gemini transcription failed (${getErrorMessage(error)}).`,
    });
  }
}
