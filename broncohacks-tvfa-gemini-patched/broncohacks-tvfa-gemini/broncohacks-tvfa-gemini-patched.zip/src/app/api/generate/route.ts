import OpenAI from "openai";
import { GoogleGenAI } from "@google/genai";
import { NextResponse } from "next/server";

import { listNotes } from "@/lib/storage";
import { buildDemoNotes, getErrorMessage, getStyleSummary } from "@/lib/utils";
import type { GenerateRequestBody, UserNote } from "@/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function buildPrompt(input: string, lectureTitle: string | undefined, notes: UserNote[]) {
  const styleExamples = notes.map((note) => `${note.title}\n${note.content}`).join("\n\n---\n\n");

  return [
    `Lecture title: ${lectureTitle?.trim() || "Untitled lecture"}`,
    "",
    "User style examples:",
    styleExamples || "No style examples provided yet.",
    "",
    "Lecture content:",
    input,
  ].join("\n");
}

async function generateWithGemini(input: string, lectureTitle: string | undefined, notes: UserNote[]) {
  const client = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
  const response = await client.models.generateContent({
    model: process.env.GEMINI_MODEL ?? "gemini-2.5-flash",
    contents: buildPrompt(input, lectureTitle, notes),
    config: {
      systemInstruction:
        "You are NoteAI. Rewrite the lecture into concise study notes that imitate the user's style examples. Keep the output clean, readable, and directly useful for studying. Do not mention that you are an AI. Do not add commentary outside the notes.",
      temperature: 0.4,
    },
  });

  const output = response.text?.trim();
  if (!output) {
    throw new Error("Gemini returned an empty response.");
  }

  return output;
}

async function generateWithOpenAI(input: string, lectureTitle: string | undefined, notes: UserNote[]) {
  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY! });
  const response = await client.responses.create({
    model: process.env.OPENAI_MODEL ?? "gpt-4o-mini",
    instructions:
      "You are NoteAI. Rewrite the lecture into concise study notes that imitate the user's style examples. Keep the output clean, readable, and directly useful for studying. Do not mention that you are an AI. Do not add commentary outside the notes.",
    input: buildPrompt(input, lectureTitle, notes),
  });

  const output = response.output_text?.trim();
  if (!output) {
    throw new Error("OpenAI returned an empty response.");
  }

  return output;
}

export async function POST(request: Request) {
  const body = (await request.json()) as GenerateRequestBody;
  const input = body.input?.trim() || body.sourceText?.trim();

  if (!input) {
    return NextResponse.json({ error: "Lecture input is required." }, { status: 400 });
  }

  const notes = await listNotes();
  const styleSummary = getStyleSummary(notes);
  const fallbackNotes = buildDemoNotes(input, body.lectureTitle, notes);
  const basePayload = {
    styleNoteCount: notes.length,
    styleSummary,
  };

  if (process.env.GEMINI_API_KEY) {
    try {
      const generated = await generateWithGemini(input, body.lectureTitle, notes);
      return NextResponse.json({
        notes: generated,
        mode: "gemini",
        ...basePayload,
      });
    } catch (error) {
      return NextResponse.json({
        notes: fallbackNotes,
        mode: "fallback",
        warning: `Gemini request failed (${getErrorMessage(error)}). Returned fallback demo notes instead.`,
        ...basePayload,
      });
    }
  }

  if (process.env.OPENAI_API_KEY) {
    try {
      const generated = await generateWithOpenAI(input, body.lectureTitle, notes);
      return NextResponse.json({
        notes: generated,
        mode: "openai",
        ...basePayload,
      });
    } catch (error) {
      return NextResponse.json({
        notes: fallbackNotes,
        mode: "fallback",
        warning: `OpenAI request failed (${getErrorMessage(error)}). Returned fallback demo notes instead.`,
        ...basePayload,
      });
    }
  }

  return NextResponse.json({
    notes: fallbackNotes,
    mode: "fallback",
    warning: "No GEMINI_API_KEY or OPENAI_API_KEY is set, so the app returned fallback demo notes instead.",
    ...basePayload,
  });
}
