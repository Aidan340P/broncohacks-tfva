import { NextResponse } from "next/server";

import { createNote, listNotes } from "@/lib/storage";

type CreateNoteBody = {
  title?: string;
  content?: string;
};

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const notes = await listNotes();
  return NextResponse.json({ notes });
}

export async function POST(request: Request) {
  const body = (await request.json()) as CreateNoteBody;
  const content = body.content?.trim();

  if (!content) {
    return NextResponse.json({ error: "Note content is required." }, { status: 400 });
  }

  const note = await createNote({
    title: body.title,
    content,
  });

  return NextResponse.json({ note }, { status: 201 });
}
