# NoteAI 📝

**BroncoHacks 2026** — Thomas Rong, Vivian Chen, Aidan Phu, and Felix Zheng

> AI-powered note-taking that adapts to *your* unique style. Turn any lecture into notes that feel like *you* wrote them.

## Features

- **Style Training** — Write a few sample notes in your natural style. The AI learns your formatting, abbreviations, level of detail, and how you organize information.
- **Note Generation (Text)** — Paste lecture slides, transcripts, or any text and get notes tailored to your personal style.
- **Note Generation (Audio Upload)** — Upload an MP3, WAV, M4A, or WebM lecture recording. The app can transcribe it with Gemini and then generate your personalized notes.
- **Live Recording** — Record a lecture directly in the browser, then let the app transcribe and convert it to your notes.
- **Lecture Library** — A shared repository where students and teachers can upload lectures. Any user can browse and convert any lecture into their own personalized notes.

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | Next.js App Router, TypeScript, Tailwind CSS |
| AI — Notes | Gemini API (Google AI Studio) |
| AI — Transcription | Gemini API audio prompting |
| Storage | JSON files (file-based, zero-config) |

## Getting Started

### 1. Install dependencies
```bash
npm install
```

### 2. Configure Gemini
```bash
cp .env.local.example .env.local
# Edit .env.local and add your Google AI Studio key
```

### 3. Start the dev server
```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## App Structure

```
src/
  app/
    page.tsx               # Dashboard / landing page
    my-notes/page.tsx      # Manage personal notes (trains AI style)
    generate/page.tsx      # Generate notes from text / audio / live mic
    lectures/page.tsx      # Public lecture repository
    api/
      notes/               # GET, POST user notes
      notes/[id]/          # PUT, DELETE a note
      lectures/            # GET, POST lectures
      lectures/[id]/       # GET, DELETE a lecture
      generate/            # POST → Gemini note generation
      transcribe/          # POST → Gemini audio transcription
  lib/
    ai.ts                  # Gemini REST helpers
    storage.ts             # JSON file read/write helpers
  types/
    index.ts               # Shared TypeScript types
data/                      # Runtime JSON storage (gitignored)
```

## Environment Variables

| Variable | Description |
|---|---|
| `GEMINI_API_KEY` | Your Google AI Studio API key |
| `GOOGLE_API_KEY` | Optional alternate name supported by Google |
| `GEMINI_MODEL` | Optional override, defaults to `gemini-2.5-flash` |
| `GEMINI_TRANSCRIPTION_MODEL` | Optional override for audio transcription |

## Notes

- If no Gemini key is set, the app falls back to demo mode so you can still test the UI.
- JSON file storage is fine for local testing, but it is not durable production storage.
