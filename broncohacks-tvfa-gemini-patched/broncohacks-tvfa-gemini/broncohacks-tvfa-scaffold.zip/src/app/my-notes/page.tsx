import { MyNotesClient } from "@/components/MyNotesClient";

export default function MyNotesPage() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight text-slate-950">My Notes</h1>
        <p className="mt-2 text-sm text-slate-600">
          Store examples of your real class notes here so the app can imitate your writing style.
        </p>
      </div>
      <MyNotesClient />
    </div>
  );
}
