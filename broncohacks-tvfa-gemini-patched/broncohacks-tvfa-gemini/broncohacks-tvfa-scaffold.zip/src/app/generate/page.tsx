import { Suspense } from "react";

import { GenerateClient } from "@/components/GenerateClient";

export default function GeneratePage() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight text-slate-950">Generate Notes</h1>
        <p className="mt-2 text-sm text-slate-600">
          Turn lecture text or audio into notes that follow the style examples from your library.
        </p>
      </div>
      <Suspense
        fallback={
          <div className="rounded-3xl border border-black/10 bg-white p-6 text-sm text-slate-600 shadow-sm">
            Loading generator...
          </div>
        }
      >
        <GenerateClient />
      </Suspense>
    </div>
  );
}
