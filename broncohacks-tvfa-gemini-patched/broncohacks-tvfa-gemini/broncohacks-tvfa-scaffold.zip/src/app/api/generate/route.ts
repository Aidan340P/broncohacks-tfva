export const runtime = "nodejs";

import { NextResponse } from "next/server";

import { getOpenAIClient } from "@/lib/openai";
import { listNotes } from "@/lib/storage";
import { buildDemoNotes, getStyleSummary } from "@/lib/utils";
import type { GenerateRequestBody } from "@/types";

export async function POST(request: Request) {
  const body = (await request.json()) as Partial<GenerateRequestBody>;
  const sourceText = body.sourceText?.trim();

  if (!sourceText) {
    return NextResponse.json({ error: "Source text is required." }, { status: 400 });
  }

  const notes = await listNotes();
  const styleNotes = notes.slice(0, 5);
  const styleSummary = getStyleSummary(styleNotes);
  const lectureTitle = body.lectureTitle?.trim() || undefined;
  const client = getOpenAIClient();

  if (!client) {
    return NextResponse.json({
      notes: buildDemoNotes(sourceText, lectureTitle, styleNotes),
      styleSummary,
      mode: "demo",
    });
  }

  const prompt = [
    lectureTitle ? `Lecture title: ${lectureTitle}` : null,
    styleSummary,
    "",
    "Style examples:",
    styleNotes.length > 0
      ? styleNotes
          .map((note, index) => `Example ${index + 1} (${note.title}):\n${note.content.slice(0, 1800)}`)
          .join("\n\n")
      : "No style examples provided. Use a concise student note format.",
    "",
    "Lecture source:",
    sourceText,
    "",
    "Write clean study notes in the user's style.",
    "Requirements:",
    "- preserve the lecture facts",
    "- match the user's formatting habits and tone",
    "- use headings or bullets when useful",
    "- do not mention that AI generated the notes",
    "- return only the notes",
  ]
    .filter(Boolean)
    .join("\n");

  try {
    const response = await client.responses.create({
      model: "gpt-4o",
      instructions: "You rewrite lecture material into student notes while preserving factual content.",
      input: prompt,
    });

    const text = response.output_text?.trim();
    if (!text) {
      return NextResponse.json({
        notes: buildDemoNotes(sourceText, lectureTitle, styleNotes),
        styleSummary,
        mode: "demo",
      });
    }

    return NextResponse.json({
      notes: text,
      styleSummary,
      mode: "openai",
    });
  } catch (error) {
    console.error("Generate route failed", error);

    return NextResponse.json({
      notes: buildDemoNotes(sourceText, lectureTitle, styleNotes),
      styleSummary,
      mode: "demo",
    });
  }
}
