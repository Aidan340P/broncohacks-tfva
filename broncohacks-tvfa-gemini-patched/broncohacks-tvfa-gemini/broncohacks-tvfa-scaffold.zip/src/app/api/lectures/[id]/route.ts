export const runtime = "nodejs";

import { NextResponse } from "next/server";

import { getLectureById } from "@/lib/storage";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const lecture = await getLectureById(id);

  if (!lecture) {
    return NextResponse.json({ error: "Lecture not found." }, { status: 404 });
  }

  return NextResponse.json(lecture);
}
