export const runtime = "nodejs";

import { NextResponse } from "next/server";

import { createNote, listNotes } from "@/lib/storage";
import type { NoteInput } from "@/types";

export async function GET() {
  const notes = await listNotes();
  return NextResponse.json(notes);
}

export async function POST(request: Request) {
  const body = (await request.json()) as Partial<NoteInput>;

  if (!body.title?.trim() || !body.content?.trim()) {
    return NextResponse.json({ error: "Title and content are required." }, { status: 400 });
  }

  const note = await createNote({
    title: body.title,
    content: body.content,
  });

  return NextResponse.json(note, { status: 201 });
}
