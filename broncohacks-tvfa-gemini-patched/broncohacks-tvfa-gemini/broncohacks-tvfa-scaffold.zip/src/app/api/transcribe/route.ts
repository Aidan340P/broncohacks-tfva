export const runtime = "nodejs";

import { NextResponse } from "next/server";
import { toFile } from "openai";

import { getOpenAIClient } from "@/lib/openai";

export async function POST(request: Request) {
  const formData = await request.formData();
  const file = formData.get("file");

  if (!(file instanceof File)) {
    return NextResponse.json({ error: "Audio file is required." }, { status: 400 });
  }

  const client = getOpenAIClient();
  if (!client) {
    return NextResponse.json({
      transcript: `[demo transcript placeholder]\nReceived audio file: ${file.name}. Add OPENAI_API_KEY to use real transcription.`,
      mode: "demo",
    });
  }

  try {
    const buffer = Buffer.from(await file.arrayBuffer());
    const transcription = await client.audio.transcriptions.create({
      file: await toFile(buffer, file.name || "lecture.webm"),
      model: "gpt-4o-mini-transcribe",
    });

    return NextResponse.json({
      transcript: transcription.text,
      mode: "openai",
    });
  } catch (error) {
    console.error("Transcription failed", error);
    return NextResponse.json({ error: "Transcription failed." }, { status: 500 });
  }
}
