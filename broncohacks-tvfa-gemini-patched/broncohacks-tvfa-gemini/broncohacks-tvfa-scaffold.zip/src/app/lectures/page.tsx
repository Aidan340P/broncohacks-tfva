import { LecturesClient } from "@/components/LecturesClient";

export default function LecturesPage() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight text-slate-950">Lecture Library</h1>
        <p className="mt-2 text-sm text-slate-600">
          Save lecture content once, then reuse it later from the generator page.
        </p>
      </div>
      <LecturesClient />
    </div>
  );
}
