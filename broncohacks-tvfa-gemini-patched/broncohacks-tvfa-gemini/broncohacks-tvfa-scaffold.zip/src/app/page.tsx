import Link from "next/link";

const features = [
  {
    title: "Train your style",
    description: "Drop in a few real notes so the generator can mimic your abbreviations, formatting, and level of detail.",
  },
  {
    title: "Generate from text or audio",
    description: "Paste lecture text, upload an audio file, or record in the browser, then turn it into study notes.",
  },
  {
    title: "Reuse a lecture library",
    description: "Save lecture text in one place and re-run it later with a different writing style.",
  },
];

const steps = [
  "Go to My Notes and add at least 3 note samples.",
  "Open Generate and paste lecture text or transcribe audio.",
  "Review the generated notes and tweak your style samples if the tone is off.",
];

export default function HomePage() {
  return (
    <div className="space-y-8">
      <section className="rounded-[2rem] border border-black/10 bg-white px-6 py-8 shadow-sm sm:px-8 sm:py-10">
        <div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
          <div>
            <span className="inline-flex rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold uppercase tracking-[0.16em] text-emerald-700">
              BroncoHacks NoteAI
            </span>
            <h1 className="mt-4 text-4xl font-semibold tracking-tight text-slate-950 sm:text-5xl">
              Lecture notes that sound like you actually wrote them.
            </h1>
            <p className="mt-4 max-w-2xl text-base leading-7 text-slate-600 sm:text-lg">
              This project was missing the entire app folder, so this scaffold gives you a working Next.js frontend,
              file-based APIs, demo data, and OpenAI hooks in one place.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link
                href="/generate"
                className="rounded-full bg-slate-900 px-5 py-3 text-sm font-semibold text-white transition hover:bg-slate-700"
              >
                Open generator
              </Link>
              <Link
                href="/my-notes"
                className="rounded-full border border-slate-300 px-5 py-3 text-sm font-semibold text-slate-700 transition hover:border-slate-900 hover:text-slate-900"
              >
                Add style notes
              </Link>
            </div>
          </div>

          <div className="rounded-3xl border border-slate-200 bg-slate-950 p-5 text-sm text-slate-100 shadow-inner">
            <p className="text-xs font-semibold uppercase tracking-[0.14em] text-emerald-300">Quick start</p>
            <ol className="mt-4 space-y-4">
              {steps.map((step, index) => (
                <li key={step} className="flex gap-3">
                  <span className="mt-0.5 inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-500/20 text-xs font-semibold text-emerald-300">
                    {index + 1}
                  </span>
                  <span className="leading-6 text-slate-200">{step}</span>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        {features.map((feature) => (
          <article key={feature.title} className="rounded-3xl border border-black/10 bg-white p-6 shadow-sm">
            <h2 className="text-lg font-semibold text-slate-900">{feature.title}</h2>
            <p className="mt-3 text-sm leading-6 text-slate-600">{feature.description}</p>
          </article>
        ))}
      </section>
    </div>
  );
}
