import { randomUUID } from "crypto";
import { mkdir, readFile, writeFile } from "fs/promises";
import path from "path";

import { DEFAULT_LECTURES, DEFAULT_NOTES } from "@/lib/sample-data";
import type { Lecture, LectureInput, Note, NoteInput } from "@/types";

const DATA_DIR = path.join(process.cwd(), "data");
const NOTES_FILE = path.join(DATA_DIR, "notes.json");
const LECTURES_FILE = path.join(DATA_DIR, "lectures.json");

async function ensureDataDir() {
  await mkdir(DATA_DIR, { recursive: true });
}

async function readCollection<T>(filePath: string, fallback: T): Promise<T> {
  await ensureDataDir();

  try {
    const raw = await readFile(filePath, "utf8");
    return JSON.parse(raw) as T;
  } catch {
    await writeCollection(filePath, fallback);
    return fallback;
  }
}

async function writeCollection<T>(filePath: string, value: T) {
  await ensureDataDir();
  await writeFile(filePath, JSON.stringify(value, null, 2), "utf8");
}

export async function listNotes() {
  const notes = await readCollection<Note[]>(NOTES_FILE, DEFAULT_NOTES);
  return notes.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}

export async function createNote(input: NoteInput) {
  const notes = await listNotes();
  const now = new Date().toISOString();

  const note: Note = {
    id: randomUUID(),
    title: input.title.trim(),
    content: input.content.trim(),
    createdAt: now,
    updatedAt: now,
  };

  const next = [note, ...notes];
  await writeCollection(NOTES_FILE, next);
  return note;
}

export async function updateNote(id: string, input: NoteInput) {
  const notes = await listNotes();
  const index = notes.findIndex((note) => note.id === id);
  if (index === -1) {
    return null;
  }

  const updated: Note = {
    ...notes[index],
    title: input.title.trim(),
    content: input.content.trim(),
    updatedAt: new Date().toISOString(),
  };

  notes[index] = updated;
  await writeCollection(NOTES_FILE, notes);
  return updated;
}

export async function deleteNote(id: string) {
  const notes = await listNotes();
  const next = notes.filter((note) => note.id !== id);
  const changed = next.length !== notes.length;
  if (changed) {
    await writeCollection(NOTES_FILE, next);
  }
  return changed;
}

export async function listLectures() {
  const lectures = await readCollection<Lecture[]>(LECTURES_FILE, DEFAULT_LECTURES);
  return lectures.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export async function createLecture(input: LectureInput) {
  const lectures = await listLectures();
  const lecture: Lecture = {
    id: randomUUID(),
    title: input.title.trim(),
    course: input.course?.trim() || undefined,
    instructor: input.instructor?.trim() || undefined,
    sourceType: input.sourceType ?? "text",
    content: input.content.trim(),
    createdAt: new Date().toISOString(),
  };

  const next = [lecture, ...lectures];
  await writeCollection(LECTURES_FILE, next);
  return lecture;
}

export async function getLectureById(id: string) {
  const lectures = await listLectures();
  return lectures.find((lecture) => lecture.id === id) ?? null;
}
