import { NextResponse } from "next/server";
import { buildGeminiWarning, hasGeminiApiKey, transcribeAudioWithGemini } from "@/lib/ai";
import type { TranscribeResponse } from "@/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const formData = await request.formData();
  const file = formData.get("file");

  if (!(file instanceof File)) {
    return NextResponse.json({ error: "Audio file is required." }, { status: 400 });
  }

  if (!hasGeminiApiKey()) {
    const text = `Transcript placeholder for ${file.name}: add GEMINI_API_KEY to get real transcription, or paste lecture text manually for now.`;
    const response: TranscribeResponse = {
      text,
      transcript: text,
      filename: file.name,
      mode: "fallback",
      warning: "GEMINI_API_KEY is not set, so the audio was not actually transcribed.",
    };

    return NextResponse.json(response);
  }

  try {
    const transcript = await transcribeAudioWithGemini(file);
    const response: TranscribeResponse = {
      text: transcript,
      transcript,
      filename: file.name,
      mode: "gemini",
    };

    return NextResponse.json(response);
  } catch (error) {
    const text = `Transcription failed for ${file.name}. Add a valid Gemini API key or paste lecture text manually.`;
    const response: TranscribeResponse = {
      text,
      transcript: text,
      filename: file.name,
      mode: "fallback",
      warning: buildGeminiWarning(error),
    };

    return NextResponse.json(response);
  }
}
