export const runtime = "nodejs";
export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";

import { deleteNote, updateNote } from "@/lib/storage";
import { makeTitle } from "@/lib/utils";
import type { NoteInput } from "@/types";

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const body = (await request.json()) as Partial<NoteInput>;
  const content = body.content?.trim();

  if (!content) {
    return NextResponse.json({ error: "Note content is required." }, { status: 400 });
  }

  const note = await updateNote(id, {
    title: body.title?.trim() || makeTitle(content, "Untitled Note"),
    content,
  });

  if (!note) {
    return NextResponse.json({ error: "Note not found." }, { status: 404 });
  }

  return NextResponse.json({ note });
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const deleted = await deleteNote(id);

  if (!deleted) {
    return NextResponse.json({ error: "Note not found." }, { status: 404 });
  }

  return NextResponse.json({ ok: true });
}
