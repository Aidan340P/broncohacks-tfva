import { NextResponse } from "next/server";
import { buildFallbackNotes } from "@/lib/fallback";
import { buildGeminiWarning, generateNotesWithGemini, hasGeminiApiKey } from "@/lib/ai";
import { listNotes } from "@/lib/storage";
import { getStyleSummary } from "@/lib/utils";
import type { GenerateRequestBody, GenerateResponse } from "@/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function buildPrompt(input: string, lectureTitle: string | undefined, styleExamples: string[], styleSummary: string) {
  return [
    "You are NoteAI.",
    "Rewrite the lecture into concise study notes that imitate the user's style examples.",
    "Keep the output clean, readable, and directly useful for studying.",
    "Do not mention that you are an AI.",
    "Do not add commentary outside the notes.",
    "",
    `Lecture title: ${lectureTitle?.trim() || "Untitled lecture"}`,
    "",
    styleSummary,
    "",
    "User style examples:",
    styleExamples.length > 0 ? styleExamples.join("\n\n---\n\n") : "No style examples provided yet.",
    "",
    "Lecture content:",
    input,
  ].join("\n");
}

export async function POST(request: Request) {
  const body = (await request.json()) as GenerateRequestBody;
  const input = body.input?.trim() || body.sourceText?.trim();

  if (!input) {
    return NextResponse.json({ error: "Lecture input is required." }, { status: 400 });
  }

  const notes = await listNotes();
  const styleSummary = getStyleSummary(notes);
  const fallbackNotes = buildFallbackNotes(input, notes, body.lectureTitle);

  if (!hasGeminiApiKey()) {
    const response: GenerateResponse = {
      notes: fallbackNotes,
      styleSummary,
      styleNoteCount: notes.length,
      mode: "fallback",
      warning: "GEMINI_API_KEY is not set, so the app returned fallback notes instead.",
    };

    return NextResponse.json(response);
  }

  try {
    const output = await generateNotesWithGemini(
      buildPrompt(
        input,
        body.lectureTitle,
        notes.map((note) => `${note.title}\n${note.content}`),
        styleSummary,
      ),
    );

    const response: GenerateResponse = {
      notes: output,
      styleSummary,
      styleNoteCount: notes.length,
      mode: "gemini",
    };

    return NextResponse.json(response);
  } catch (error) {
    const response: GenerateResponse = {
      notes: fallbackNotes,
      styleSummary,
      styleNoteCount: notes.length,
      mode: "fallback",
      warning: buildGeminiWarning(error),
    };

    return NextResponse.json(response);
  }
}
