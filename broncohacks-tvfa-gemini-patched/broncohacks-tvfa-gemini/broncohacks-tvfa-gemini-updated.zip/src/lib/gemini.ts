import { GoogleGenAI } from "@google/genai";

let client: GoogleGenAI | null = null;
let cachedKey = "";

export function getGeminiApiKey() {
  return process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || "";
}

export function getGeminiClient() {
  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    return null;
  }

  if (!client || cachedKey !== apiKey) {
    client = new GoogleGenAI({ apiKey });
    cachedKey = apiKey;
  }

  return client;
}
