import { randomUUID } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";

import { seedLectures } from "@/lib/seeds";
import { makeTitle } from "@/lib/utils";
import type { Lecture, LectureInput, UserNote } from "@/types";

const dataDirectory = path.join(process.cwd(), "data");
const notesFile = path.join(dataDirectory, "notes.json");
const lecturesFile = path.join(dataDirectory, "lectures.json");

async function ensureDataDirectory() {
  await mkdir(dataDirectory, { recursive: true });
}

async function readCollection<T>(filePath: string, fallback: T[] = []): Promise<T[]> {
  await ensureDataDirectory();

  try {
    const raw = await readFile(filePath, "utf8");
    const parsed = JSON.parse(raw) as unknown;
    return Array.isArray(parsed) ? (parsed as T[]) : fallback;
  } catch (error) {
    const isMissing =
      typeof error === "object" &&
      error !== null &&
      "code" in error &&
      (error as { code?: string }).code === "ENOENT";

    if (!isMissing) {
      return fallback;
    }

    await writeFile(filePath, JSON.stringify(fallback, null, 2), "utf8");
    return fallback;
  }
}

async function writeCollection<T>(filePath: string, records: T[]) {
  await ensureDataDirectory();
  await writeFile(filePath, JSON.stringify(records, null, 2), "utf8");
}

function sortByUpdatedAt<T extends { updatedAt?: string; createdAt?: string }>(records: T[]) {
  return [...records].sort((a, b) => {
    const aValue = new Date(a.updatedAt ?? a.createdAt ?? 0).getTime();
    const bValue = new Date(b.updatedAt ?? b.createdAt ?? 0).getTime();
    return bValue - aValue;
  });
}

export async function listNotes(): Promise<UserNote[]> {
  const notes = await readCollection<UserNote>(notesFile, []);
  return sortByUpdatedAt(notes);
}

export async function getNoteById(id: string): Promise<UserNote | null> {
  const notes = await listNotes();
  return notes.find((note) => note.id === id) ?? null;
}

export async function saveNote(note: UserNote): Promise<UserNote> {
  const notes = await readCollection<UserNote>(notesFile, []);
  const existingIndex = notes.findIndex((item) => item.id === note.id);

  if (existingIndex >= 0) {
    notes[existingIndex] = note;
  } else {
    notes.unshift(note);
  }

  await writeCollection(notesFile, sortByUpdatedAt(notes));
  return note;
}

export async function updateNote(
  id: string,
  updates: Pick<UserNote, "title" | "content">,
): Promise<UserNote | null> {
  const existing = await getNoteById(id);
  if (!existing) {
    return null;
  }

  const updated: UserNote = {
    ...existing,
    title: updates.title.trim() || makeTitle(updates.content, existing.title),
    content: updates.content.trim(),
    updatedAt: new Date().toISOString(),
  };

  await saveNote(updated);
  return updated;
}

export async function deleteNote(id: string): Promise<boolean> {
  const notes = await readCollection<UserNote>(notesFile, []);
  const nextNotes = notes.filter((note) => note.id !== id);

  if (nextNotes.length === notes.length) {
    return false;
  }

  await writeCollection(notesFile, sortByUpdatedAt(nextNotes));
  return true;
}

export const removeNote = deleteNote;

export async function listLectures(): Promise<Lecture[]> {
  const lectures = await readCollection<Lecture>(lecturesFile, seedLectures);

  if (lectures.length === 0) {
    await writeCollection(lecturesFile, seedLectures);
    return seedLectures;
  }

  return sortByUpdatedAt(lectures);
}

export async function getLectureById(id: string): Promise<Lecture | null> {
  const lectures = await listLectures();
  return lectures.find((lecture) => lecture.id === id) ?? null;
}

export async function saveLecture(lecture: Lecture): Promise<Lecture> {
  const lectures = await readCollection<Lecture>(lecturesFile, seedLectures);
  const existingIndex = lectures.findIndex((item) => item.id === lecture.id);

  if (existingIndex >= 0) {
    lectures[existingIndex] = lecture;
  } else {
    lectures.unshift(lecture);
  }

  await writeCollection(lecturesFile, sortByUpdatedAt(lectures));
  return lecture;
}

export async function createLecture(input: LectureInput): Promise<Lecture> {
  const now = new Date().toISOString();
  const lecture: Lecture = {
    id: randomUUID(),
    title: input.title.trim(),
    course: input.course?.trim() || undefined,
    instructor: input.instructor?.trim() || undefined,
    content: input.content.trim(),
    sourceType: input.sourceType ?? "text",
    createdAt: now,
    updatedAt: now,
  };

  await saveLecture(lecture);
  return lecture;
}

export async function deleteLecture(id: string): Promise<boolean> {
  const lectures = await readCollection<Lecture>(lecturesFile, seedLectures);
  const nextLectures = lectures.filter((lecture) => lecture.id !== id);

  if (nextLectures.length === lectures.length) {
    return false;
  }

  await writeCollection(lecturesFile, sortByUpdatedAt(nextLectures));
  return true;
}

export const removeLecture = deleteLecture;
