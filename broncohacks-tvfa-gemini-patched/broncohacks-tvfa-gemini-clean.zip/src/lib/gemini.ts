import { getErrorMessage } from "@/lib/utils";

const GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta";
const INLINE_AUDIO_SOFT_LIMIT_BYTES = 18 * 1024 * 1024;

const SUPPORTED_AUDIO_MIME_TYPES = new Set([
  "audio/wav",
  "audio/mp3",
  "audio/aiff",
  "audio/aac",
  "audio/ogg",
  "audio/flac",
]);

type GeminiTextResponse = {
  candidates?: Array<{
    content?: {
      parts?: Array<{
        text?: string;
      }>;
    };
  }>;
  error?: {
    message?: string;
  };
};

export function getGeminiApiKey() {
  return process.env.GEMINI_API_KEY?.trim() || process.env.GOOGLE_API_KEY?.trim() || "";
}

export function hasGeminiKey() {
  return Boolean(getGeminiApiKey());
}

export function describeGeminiFailure(error: unknown) {
  return getErrorMessage(error);
}

export function getInlineAudioSoftLimitBytes() {
  return INLINE_AUDIO_SOFT_LIMIT_BYTES;
}

export function toBase64(input: ArrayBuffer) {
  return Buffer.from(input).toString("base64");
}

function getGeminiModel() {
  return process.env.GEMINI_MODEL?.trim() || "gemini-2.5-flash";
}

function getGeminiTranscriptionModel() {
  return process.env.GEMINI_TRANSCRIPTION_MODEL?.trim() || getGeminiModel();
}

function normalizeAudioMimeType(mimeType: string) {
  const value = mimeType.trim().toLowerCase();
  if (value === "audio/mpeg") return "audio/mp3";
  if (value === "audio/x-wav") return "audio/wav";
  if (value === "audio/x-aiff") return "audio/aiff";
  return value;
}

function extractGeminiText(payload: GeminiTextResponse) {
  const text = payload.candidates
    ?.flatMap((candidate) => candidate.content?.parts ?? [])
    .map((part) => part.text ?? "")
    .join("")
    .trim();

  if (!text) {
    throw new Error(payload.error?.message || "Gemini returned an empty response.");
  }

  return text;
}

async function callGemini(parts: Array<Record<string, unknown>>, model: string) {
  const apiKey = getGeminiApiKey();

  if (!apiKey) {
    throw new Error("Missing GEMINI_API_KEY or GOOGLE_API_KEY.");
  }

  const response = await fetch(`${GEMINI_API_URL}/models/${model}:generateContent`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-goog-api-key": apiKey,
    },
    body: JSON.stringify({
      contents: [
        {
          role: "user",
          parts,
        },
      ],
    }),
  });

  const payload = (await response.json()) as GeminiTextResponse;

  if (!response.ok) {
    throw new Error(payload.error?.message || `Gemini request failed with status ${response.status}.`);
  }

  return extractGeminiText(payload);
}

export async function generateStudyNotes({ prompt }: { prompt: string }) {
  return callGemini([{ text: prompt }], getGeminiModel());
}

export async function transcribeAudioInline({
  base64Data,
  mimeType,
}: {
  base64Data: string;
  mimeType: string;
  filename?: string;
}) {
  const normalizedMimeType = normalizeAudioMimeType(mimeType || "audio/wav");

  if (!SUPPORTED_AUDIO_MIME_TYPES.has(normalizedMimeType)) {
    throw new Error(
      "Unsupported audio format. Gemini inline transcription in this app supports WAV, MP3, AIFF, AAC, OGG, and FLAC.",
    );
  }

  const prompt = [
    "Generate only a clean transcript of the spoken audio.",
    "Do not add headings, timestamps, speaker labels, bullet points, or commentary.",
  ].join(" ");

  return callGemini(
    [
      { text: prompt },
      {
        inline_data: {
          mime_type: normalizedMimeType,
          data: base64Data,
        },
      },
    ],
    getGeminiTranscriptionModel(),
  );
}
